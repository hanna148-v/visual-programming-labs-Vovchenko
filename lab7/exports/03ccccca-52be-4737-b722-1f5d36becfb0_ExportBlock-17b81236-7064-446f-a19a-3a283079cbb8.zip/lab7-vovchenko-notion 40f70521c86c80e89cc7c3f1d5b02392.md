# lab7-vovchenko-notion

# Локации

[Locations-vovchenko](Locations-vovchenko%2041070521c86c808294f9cc31de615692.csv)

# Сотрудники

[Keepers-vovchenko](Keepers-vovchenko%2041070521c86c801b8ee8ceabf3f53d8f.csv)

# Растения

[Plants-vovchenko](Plants-vovchenko%2041070521c86c80178c51fec6c0e02217.csv)

# Журнал подкормок

[Feedings-vovchenko](Feedings-vovchenko%2041070521c86c808e8d91c37cd2108390.csv)